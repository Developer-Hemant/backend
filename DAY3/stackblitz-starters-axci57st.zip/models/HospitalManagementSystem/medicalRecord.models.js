import mongoose from 'mongoose';

const medicalRecordSchema = new mongoose.Schema(
  {
    hospitalname: [
      {
        hospital: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Hospital',
          required: true,
        },
        patientlist: [
          {
            name: {
              type: mongoose.Schema.Types.ObjectId,
              ref: 'patients',
              required: true,
            },
            visitDate: {
              type: Date,
              default: Date.now,
              required: true,
            },
            diagnosis: String,
            presciption: String,
            dosctor: {
              type: mongoose.Schema.Types.ObjectId,
              ref: 'doctors',
            },
            status: {
              type: String,
              enum: ['Admitted', 'Discharged', 'Under Treatment'],
              default: 'Under Treatment',
            },
          },
        ],
      },
    ],
  },
  { timestamps: true }
);

export const medicalRecords = mongoose.model(
  'medicalRecords',
  medicalRecordSchema
);
