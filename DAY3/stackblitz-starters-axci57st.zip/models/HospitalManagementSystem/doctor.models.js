import mongoose from 'mongoose';

const doctorSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    salary: {
      type: String, //string iss liye kyuki maan lo 100"$"or"Rs" toh ye toh string h na 100 hee h bas number toh string liya
      required: true,
    },
    qualification: {
      type: String,
      required: true,
    },
    experienceInYears: {
      type: Number,
      default: 0,
    },
    worksInHospitals: [
      {
        hospital: {
          // type: mongoose.Schema.Type.ObjectId, Type is wrong we have to use Types instead
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Hospital',
        },
        workingHours: {
          type: Number,
          required: true,
        },
      },
    ],
  },
  { timestamps: true }
);

export const doctors = mongoose.model('doctors', doctorSchema);
