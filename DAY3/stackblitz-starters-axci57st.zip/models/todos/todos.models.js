//pehle isko import karenge
import mongoose from 'mongoose';

//schema banayenge
const todoSchema = new mongoose.Schema(
  {
    content: {
      type: String,
      required: true,
    },
    complete: {
      type: Boolean,
      default: false,
    },
    createdBy: {
      //special type
      //reference
      type: mongoose.Schema.Types,
      ObjectId,
      ref: 'User',
    },
    subTodos: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'SubToDo',
      },
    ],//array of subtodos
  },
  { timestamps: true }
);

//export karenge
export const Todo = mongoose.model('Todo', todoSchema);

//timestamp nhi
//timestamps kyuki createdAt updatedAt.
