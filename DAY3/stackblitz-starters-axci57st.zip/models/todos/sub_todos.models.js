//import karenge
import mongoose from 'mongoose';

//schema banani h
const subTodoSchema = new mongoose.Schema(
  {
    content: {
      type: String,
      required: true,
    },
    complete: {
      type: Boolean,
      default: false,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  { timestamps: true }
);

//export karenge
export const SubToDo = mongoose.model('SubToDo', subTodoSchema);
