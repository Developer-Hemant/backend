//pehle import karenge
import mongoose from 'mongoose';

//fir schema banani hai
const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
    },
    password: {
      type: String,
      required: true,
    },
    isActive: Boolean,
  },
  { timestamps: true }
);

//fir export karna hai
export const User = mongoose.model('User', userSchema);
