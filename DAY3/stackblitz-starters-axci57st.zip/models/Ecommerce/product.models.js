import mongoose from 'mongoose';

const productSchema = new mongoose.Schema(
  {
    description:{
      type:String,
      required: true,
      default:false
    },
    name:{
      type:String,
      required: true
    },
    productImages:{
       type: String
    },
    price:{
      type: Number,
      default: 0,
      currency: IND
    },
    stock:{
      type: number,
      default: 0
    },
    category:{
      type: mongoose.Schema.Types.ObjectId,
      ref: "Cdata",
      required: true
    },
    ownership:{
      type: mongoose.Schema.Types.ObjectId,
      ref: "Users",
      required: true
    }
  },
{ timestamps: true });

export const Pdata = mongoose.model('Pdata', productSchema);
